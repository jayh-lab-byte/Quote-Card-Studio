# Quote Card Studio

React + Vite + JavaScript quote card editor using Unsplash, Canvas, and localStorage.

## Run

1. Install Node.js and pnpm.
2. Run `pnpm install`.
3. Copy `.env.example` to `.env` and set `VITE_UNSPLASH_ACCESS_KEY` to your Unsplash Access Key.
4. Run `pnpm dev` and open the URL printed in the terminal.

Build: `pnpm build`.

Only click Search to fetch images. Select a photo, edit your quote, and click Download PNG.

Do not commit `.env`, API credentials, `node_modules`, or `dist`. Only the public Access Key is used; no Secret Key is needed. The browser receives the Access Key through Vite.

This archive intentionally excludes credentials and dependencies. Extract it and upload the files inside the quote-card-studio folder to your repository, including `.gitignore` and `.env.example`.
